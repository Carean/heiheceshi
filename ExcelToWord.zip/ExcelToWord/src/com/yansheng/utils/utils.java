package com.yansheng.utils;

public class utils {
	public static String FormatFileName(String fileName,String date){
		//fileName=fileName.substring(arg0)
		
		return fileName;
	} 
}
